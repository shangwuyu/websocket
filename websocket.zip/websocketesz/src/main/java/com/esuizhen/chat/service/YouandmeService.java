package com.esuizhen.chat.service;

import java.sql.Timestamp;

import org.springframework.stereotype.Service;

import com.esuizhen.chat.entity.Message;

/** 
 *@className YouandmeService
 *@Description:
 *@author yuanwenming
 *@date 2018年2月1日
 */
@Service
public class YouandmeService {
	public void addMessage(int fromId,String fromName,int toId,String messageText,Timestamp messageDate){
		Message msg = new Message(fromId,fromName,toId,messageText,messageDate);
		System.out.println("###########"+msg.toString());
	}
}
