package com.esuizhen.chat.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.esuizhen.chat.entity.User;
import com.westangel.common.bean.ErrorMessage;
import com.westangel.common.bean.TMsgResponse;
import com.westangel.common.util.LogUtil;

/** 
 *@className UserController
 *@Description:
 *@author yuanwenming
 *@date 2018年2月1日
 */
@Controller
public class UserController {
	@Autowired
	private MessageSource messageSource;
	
	@ResponseBody
	@RequestMapping(value="/user/all",method=RequestMethod.GET)
	public TMsgResponse<List<User>> queryAll(HttpServletRequest request ,Locale locale) {
		LogUtil.log.info("开始 获取患者列表:");
		TMsgResponse<List<User>> msg = new TMsgResponse<List<User>>();
		msg.setRespCode(ErrorMessage.SUCCESS.getCode());
		msg.setRespMsg(messageSource.getMessage(ErrorMessage.SUCCESS.info, null, locale));
		try {
			List<User> userList = new ArrayList<User>();
			User user = new User();
			user.setId(1);
			user.setName("文明");
			User user1 = new User();
			user1.setId(2);
			user1.setName("张三");
			User user2 = new User();
			user2.setId(3);
			user2.setName("李四");
			userList.add(user);
			userList.add(user1);
			userList.add(user2);
			msg.setResult(userList);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return msg;
	}
	@ResponseBody
	@RequestMapping(value="/user/one",method=RequestMethod.GET)
	public TMsgResponse<List<User>> queryOne(HttpServletRequest request ,Integer id,Locale locale) {
		LogUtil.log.info("开始 获取患者列表:");
		TMsgResponse<List<User>> msg = new TMsgResponse<List<User>>();
		msg.setRespCode(ErrorMessage.SUCCESS.getCode());
		msg.setRespMsg(messageSource.getMessage(ErrorMessage.SUCCESS.info, null, locale));
		try {
			User user = new User();
			user.setId(id);
			HttpSession sesson = request.getSession(true);
			sesson.setAttribute("user", user);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return msg;
	}
}
